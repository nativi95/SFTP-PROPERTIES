/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.excel;


import com.mycompany.sftpreport.config.ReportConfig;
import com.mycompany.sftpreport.model.FixedColumn;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class ExcelConverter {

    public static String convert(String inputFile, ReportConfig config) throws Exception {

        System.out.println("Leyendo archivo...");
        List<String> lines = Files.readAllLines(new File(inputFile).toPath());
        System.out.println("Lineas leidas: " + lines.size());
        int maxLen = 0;

        for (String line : lines) {
            if (line.length() > maxLen) {
                maxLen = line.length();
            }
        }
System.out.println("Longitud maxima de linea: " + maxLen);
        //Workbook workbook = new XSSFWorkbook();
        System.out.println("Creando workbook...");
        SXSSFWorkbook workbook = new SXSSFWorkbook(100);
        System.out.println("Workbook creado.");
        Sheet sheet = workbook.createSheet("Reporte");

        System.out.println("Iniciando conversion...");
        // ✅ ESTILO TEXTO (una sola vez)
        CellStyle textStyle = workbook.createCellStyle();
        DataFormat format = workbook.createDataFormat();
        textStyle.setDataFormat(format.getFormat("@"));

        int rowNum = 0;
        Row header = sheet.createRow(rowNum++);

        // =========================
        // DELIMITED
        // =========================
        if ("DELIMITED".equalsIgnoreCase(config.getFileType())) {

            String delimiter = config.getDelimiter();

            String[] headers = config.getColumns()
                    .split(java.util.regex.Pattern.quote(delimiter));

            // Encabezados
            for (int i = 0; i < headers.length; i++) {
                header.createCell(i).setCellValue(headers[i]);
            }

            int startIndex = config.hasHeader() ? 1 : 0;

            for (int i = startIndex; i < lines.size(); i++) {

                String line = lines.get(i);
                if (i % 500 == 0) {
                    System.out.println("Procesadas: " + i + " lineas de " + lines.size());
                }

                if (line.trim().isEmpty()) continue;

                Row row = sheet.createRow(rowNum++);

                String[] values = line.split(java.util.regex.Pattern.quote(delimiter));

                for (int j = 0; j < values.length; j++) {

                    String headerName = (j < headers.length) ? headers[j] : "COL_" + j;
                    String value = values[j].trim();

                    value = applyTransformations(headerName, value, config);

                    Cell cell = row.createCell(j);

                    // ✅ TEXTO REAL (sin apostrofe visible)
                    String asText = config.getColumnTransform(headerName, "text");

                    if ("true".equalsIgnoreCase(asText)) {
                        cell.setCellValue(value);
                        cell.setCellStyle(textStyle);
                    } else {
                        cell.setCellValue(value);
                    }
                }
            }
        }

        // =========================
        // FIXED
        // =========================
        else if ("FIXED".equalsIgnoreCase(config.getFileType())) {

            List<FixedColumn> cols = config.getFixedColumns();

            // Encabezados
            for (int i = 0; i < cols.size(); i++) {
                header.createCell(i).setCellValue(cols.get(i).getName());
            }

            int startIndex = config.hasHeader() ? 1 : 0;

            for (int i = startIndex; i < lines.size(); i++) {

                String line = lines.get(i);

                if (line.trim().isEmpty()) continue;

                Row row = sheet.createRow(rowNum++);

                for (int j = 0; j < cols.size(); j++) {

                    FixedColumn col = cols.get(j);

                    String value = safeSubstring(line, col.getStart(), col.getEnd()).trim();

                    value = applyTransformations(col.getName(), value, config);

                    Cell cell = row.createCell(j);

                    String asText = config.getColumnTransform(col.getName(), "text");

                    if ("true".equalsIgnoreCase(asText)) {
                        cell.setCellValue(value);
                        cell.setCellStyle(textStyle);
                    } else {
                        cell.setCellValue(value);
                    }
                }
            }
        }

        // =========================
        // GUARDAR
        // =========================
        String output = inputFile.replaceAll("\\.[^.]+$", ".xlsx");

        FileOutputStream fos = new FileOutputStream(output);
        workbook.write(fos);
        System.out.println("Excel escrito en memoria.");
        fos.close();
        workbook.dispose();
        workbook.close();
        System.out.println("Excel generado correctamente.");
        return output;
    }

    // =========================
    // TRANSFORMACIONES
    // =========================
    private static String applyTransformations(String column, String value, ReportConfig config) {

        if (value == null || value.isEmpty()) return value;

        try {

            // ✅ DIVIDE
            String divide = config.getColumnTransform(column, "divide");
            if (divide != null) {
                double num = Double.parseDouble(value);
                double result = num / Double.parseDouble(divide);
                return String.format("%.2f", result);
            }

            // ✅ FECHA
            String format = config.getColumnTransform(column, "format");
            String outputFormat = config.getColumnTransform(column, "outputFormat");

            if (format != null && outputFormat != null) {

                DateTimeFormatter in = DateTimeFormatter.ofPattern(format);
                DateTimeFormatter out = DateTimeFormatter.ofPattern(outputFormat);

                LocalDate date = LocalDate.parse(value, in);

                return date.format(out);
            }

            // ✅ UPPER
            String upper = config.getColumnTransform(column, "upper");
            if ("true".equalsIgnoreCase(upper)) {
                return value.toUpperCase();
            }

        } catch (Exception e) {
            System.out.println("⚠️ Error transformando [" + column + "] valor: " + value);
        }

        return value;
    }

    // =========================
    // SUBSTRING SEGURO
    // =========================
    private static String safeSubstring(String line, int start, int end) {

        if (start >= line.length()) return "";

        int safeEnd = Math.min(end, line.length());

        return line.substring(start, safeEnd);
    }
}