/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.config;

import java.util.*;
import com.mycompany.sftpreport.util.CryptoUtil;
import com.mycompany.sftpreport.model.FixedColumn;
import com.mycompany.sftpreport.util.DateTemplateUtil;

public class ReportConfig {

    private Properties props;

    public ReportConfig(Properties props) {
        this.props = props;
    }

    // SFTP
    public String getHost() {
        return props.getProperty("sftp.host");
    }

    public int getPort() {
        return Integer.parseInt(props.getProperty("sftp.port", "22"));
    }

    public String getUser() {
        return props.getProperty("sftp.user");
    }

    public String getPassword() {
        try {
            return CryptoUtil.decrypt(props.getProperty("sftp.password"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getRemotePath() {
        return props.getProperty("sftp.remote.path");
    }

    public String getRemoteTemplate() {
        return props.getProperty("sftp.remote.template");
    }

    // LOCAL
    public String getLocalPath() {
        return props.getProperty("local.download.path");
    }

    public void setLocalPath(String path) {
        props.setProperty("local.download.path", path);
    }

// =========================
// HEADER ARCHIVO
// =========================
    public boolean hasHeader() {
        return Boolean.parseBoolean(props.getProperty("file.hasHeader", "false"));
    }

    // FLAGS
    public boolean isConvertExcel() {
        return Boolean.parseBoolean(props.getProperty("convert.excel", "false"));
    }

    public boolean isSendMail() {
        return Boolean.parseBoolean(props.getProperty("send.mail", "false"));
    }

    // FILE
    public String getFileType() {
        return props.getProperty("file.type", "DELIMITED");
    }

    public String getDelimiter() {
        return props.getProperty("delimiter", "|");
    }

    public String getColumns() {
        return props.getProperty("columns", "");
    }

    // FIXED
    public List<FixedColumn> getFixedColumns() {

        String config = props.getProperty("fixed.columns");
        List<FixedColumn> list = new ArrayList<>();

        if (config == null || config.trim().isEmpty()) {
            return list;
        }

        for (String col : config.split(",")) {
            try {
                String[] parts = col.split(":");
                String name = parts[0];

                String[] range = parts[1].split("-");
                int start = Integer.parseInt(range[0]);
                int end = Integer.parseInt(range[1]);

                list.add(new FixedColumn(name, start, end));

            } catch (Exception e) {
                System.out.println("Error columna FIXED: " + col);
            }
        }

        return list;
    }

    // TRANSFORMACIONES
    public String getColumnTransform(String column, String type) {
        return props.getProperty("column." + column + "." + type);
    }

    // MAIL
    public String getMailHost() {
        return props.getProperty("mail.smtp.host");
    }

    public String getMailPort() {
        return props.getProperty("mail.smtp.port");
    }

    public String getMailUser() {
        return props.getProperty("mail.user");
    }

    public String getMailPassword() {
        try {
            return CryptoUtil.decrypt(props.getProperty("mail.password"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getMailTo() {
        return props.getProperty("mail.to");
    }

    public String getMailSubjectTemplate() {
        return props.getProperty("mail.subject.template", "{report} - {date}");
    }

    //sql
    // =========================
// SOURCE
// =========================
    public String getSourceType() {
        return props.getProperty("source.type", "SFTP");
    }
// =========================
// SQL
// =========================

    public String getSqlUser() {
        return props.getProperty("sql.user");
    }

    public String getSqlPassword() {
        try {
            return CryptoUtil.decrypt(
                    props.getProperty("sql.password")
            );
        } catch (Exception e) {
            throw new RuntimeException(
                    "Error desencriptando password SQL",
                    e
            );
        }
    }

    public String getSqlTns() {
        return props.getProperty("sql.tns");
    }

    public String getSqlScript() {
        return props.getProperty("sql.script");
    }

    public String getSqlOutputFile() {
        return DateTemplateUtil.resolveDates(
            props.getProperty("sql.output.file"));
    }

    public String getOracleHome() {
        return props.getProperty("oracle.home");
    }

    public boolean isTextTransform() {
        return Boolean.parseBoolean(
                props.getProperty(
                        "transform.txt",
                        "false"));
    }

    public boolean isIncludeHeader() {
        return Boolean.parseBoolean(
                props.getProperty(
                        "output.includeHeader",
                        "true"
                )
        );
    }
    
public String getMergeOutputFile() {

    String fileName =
            DateTemplateUtil.resolveDates(
                    props.getProperty(
                            "merge.output.file"));

    return getLocalPath() + fileName;
}
    
public boolean isSkipMergeHeaders() {

    return Boolean.parseBoolean(
            props.getProperty(
                    "merge.skipHeaders",
                    "false"));
}

public List<String> getSqlParams() {

    String params =
            props.getProperty("sql.params");

    if (params == null
            || params.trim().isEmpty()) {

        return Collections.emptyList();
    }

    return Arrays.asList(
            params.split("\\|"));
}

public String getSqlPlusPath() {
    return props.getProperty("sqlplus.path");
}

public String getTnsAdmin() {
    return props.getProperty("tns.admin");
}
}
