/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.sftpreport;

import com.mycompany.sftpreport.sql.SqlExecutor;

import com.mycompany.sftpreport.config.*;
import com.mycompany.sftpreport.sftp.SftpClient;
import com.mycompany.sftpreport.excel.ExcelConverter;
import com.mycompany.sftpreport.mailsender.MailSender;
import com.mycompany.sftpreport.ui.EncryptTool;
import com.mycompany.sftpreport.textTransformer.TextTransformer;
import com.mycompany.sftpreport.merge.MergeProcessor;
import com.mycompany.sftpreport.util.LoggerUtil;
import java.io.File;
import java.time.LocalDate;
import java.util.*;

/**
 *
 * @author juan_nativi
 */
public class SFTPreport {

    public static void main(String[] args) {
        LoggerUtil.log("Verion 13.10.26-13.49");//fecha y hora
        try {

            // ✅ SI NO HAY ARGUMENTOS → abrir UI
            if (args.length == 0) {
                EncryptTool.show();
                return;
            }

            List<String> reports = Arrays.asList(args[0]);

            for (String reportName : reports) {

                ReportConfig config = ConfigLoader.load(reportName);

                String path = "C:\\SFTPreport\\output\\" + reportName + "\\" + LocalDate.now() + "\\";
                config.setLocalPath(path);

                String file;
                switch (config.getSourceType().toUpperCase()) {
                    case "SQL":
                        file = SqlExecutor.execute(config);
                        break;
                    case "SFTP":
                    default:
                        file = SftpClient.download(config, reportName);
                        LoggerUtil.log("transform.txt = " + config.isTextTransform());
                        LoggerUtil.log("file.hasHeader = " + config.hasHeader());
                        LoggerUtil.log("output.includeHeader = " + config.isIncludeHeader());
                        if (config.isTextTransform()) {

                            file = TextTransformer.transform(
                                    file,
                                    config
                            );
                        }
                        break;
                    case "MERGE":

                        String sqlFile
                                = SqlExecutor.execute(config);

                        String sftpFile
                                = SftpClient.download(config, reportName);

                        if (config.isTextTransform()) {

                            sftpFile
                                    = TextTransformer.transform(
                                            sftpFile,
                                            config);
                        }

                        file
                                = MergeProcessor.merge(
                                        sqlFile,
                                        sftpFile,
                                        config);

                        break;
                }

                String finalFile = file;

                if (config.isConvertExcel() && !file.toLowerCase().endsWith("xlsx")) {
                    finalFile = ExcelConverter.convert(file, config);
                }

                if (config.isSendMail()) {
                    MailSender.send(config, finalFile, reportName);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
