/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.ui;


import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.StringSelection;

import com.mycompany.sftpreport.util.CryptoUtil;

public class EncryptTool {

    public static void show() {

        JFrame frame = new JFrame("SFTP Report - Encrypt Tool");

        JTextField inputField = new JTextField();
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);

        JButton encryptButton = new JButton("Encriptar");
        JButton copyButton = new JButton("Copiar");

        encryptButton.addActionListener(e -> {
            try {
                String value = inputField.getText();

                if (value.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Ingrese un valor");
                    return;
                }

                String encrypted = CryptoUtil.encrypt(value);

                outputArea.setText(encrypted);

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            }
        });

        copyButton.addActionListener(e -> {
            StringSelection selection = new StringSelection(outputArea.getText());
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
        });

        JPanel panel = new JPanel(new GridLayout(4, 1));

        panel.add(new JLabel("Texto a encriptar:"));
        panel.add(inputField);
        panel.add(encryptButton);
        panel.add(new JScrollPane(outputArea));

        frame.add(panel, BorderLayout.CENTER);
        frame.add(copyButton, BorderLayout.SOUTH);

        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
