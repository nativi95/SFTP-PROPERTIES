package com.mycompany.sftpreport.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateTemplateUtil {

    /**
     * Reemplaza variables dinámicas de fecha dentro de una plantilla.
     *
     * Variables soportadas:
     *
     * {today:FORMATO} {yesterday:FORMATO} {lastdaymonth:FORMATO}
     * {lastmonth:FORMATO}
     *
     * Ejemplos: {today:yyyyMMdd} {yesterday:ddMMyyyy} {lastdaymonth:dd-MM-yyyy}
     * {lastmonth:MMyyyy}
     */
    public static String resolveDates(String template) {

        if (template == null || template.isEmpty()) {
            return template;
        }

        Pattern pattern
                = Pattern.compile("\\{(today|yesterday|lastdaymonth|lastmonth|firstdaylastmonth|firstdaymonth):([^}]+)\\}");

        Matcher matcher = pattern.matcher(template);

        StringBuffer result = new StringBuffer();

        LocalDate today = LocalDate.now();

        while (matcher.find()) {

            String variable = matcher.group(1);
            String format = matcher.group(2);

            LocalDate date;

            switch (variable.toLowerCase()) {

                case "today":
                    date = today;
                    break;

                case "yesterday":
                    date = today.minusDays(1);
                    break;

                case "lastdaymonth":
                    date = today.withDayOfMonth(1).minusDays(1);
                    break;

                case "lastmonth":
                    date = today.minusMonths(1);
                    break;

                case "firstdaymonth":
                    date = today.withDayOfMonth(1);
                    break;

                case "firstdaylastmonth":
                    date = today.minusMonths(1)
                            .withDayOfMonth(1);
                    break;

                default:
                    date = today;
            }

            String replacement
                    = date.format(DateTimeFormatter.ofPattern(format));

            matcher.appendReplacement(
                    result,
                    Matcher.quoteReplacement(replacement)
            );
        }

        matcher.appendTail(result);

        return result.toString();
    }
}
