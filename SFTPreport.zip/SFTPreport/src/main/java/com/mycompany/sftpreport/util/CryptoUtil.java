package com.mycompany.sftpreport.util;



import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author juan_nativi
 */
public class CryptoUtil {
    
private static final String ALGORITHM = "AES";

    public static String decrypt(String encryptedText) throws Exception {

        String key = System.getenv("APP_AES_KEY");

        if (key == null || key.isEmpty()) {
            throw new RuntimeException("Variable APP_AES_KEY no definida");
        }

        SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        byte[] decoded = Base64.getDecoder().decode(encryptedText);
        byte[] decrypted = cipher.doFinal(decoded);

        return new String(decrypted);
    }
    
    
public static String encrypt(String value) throws Exception {

    String key = System.getenv("APP_AES_KEY");

    if (key == null || key.isEmpty()) {
        throw new RuntimeException("Variable APP_AES_KEY no definida");
    }

    SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);

    Cipher cipher = Cipher.getInstance(ALGORITHM);
    cipher.init(Cipher.ENCRYPT_MODE, secretKey);

    byte[] encrypted = cipher.doFinal(value.getBytes());

    return Base64.getEncoder().encodeToString(encrypted);
}

}
