package com.mycompany.sftpreport.sql;

import com.mycompany.sftpreport.config.ReportConfig;
import com.mycompany.sftpreport.util.DateTemplateUtil;
import com.mycompany.sftpreport.util.LoggerUtil;
import java.io.BufferedReader;

import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SqlExecutor {

    public static String execute(ReportConfig config) throws Exception {

        LoggerUtil.log("Inicio ejecución SQL");

       String sqlplus =
        config.getSqlPlusPath();

      List<String> command =
        new ArrayList<>();

command.add(sqlplus);

command.add("-S");

command.add(
        config.getSqlUser()
        + "/"
        + config.getSqlPassword()
        + "@"
        + config.getSqlTns());

command.add(
        "@"
        + config.getSqlScript());

command.add(
        config.getSqlOutputFile());


for (String param : config.getSqlParams()) {

    command.add(
            DateTemplateUtil.resolveDates(
                    param.trim()));
}

for (int i = 0; i < command.size(); i++) {

    if (i == 2) {

        LoggerUtil.log(
                "Parametro [" + i + "] = ********");

    } else {

        LoggerUtil.log(
                "Parametro [" + i + "] = "
                + command.get(i));
    }
}


ProcessBuilder pb =
        new ProcessBuilder(command);

        Map<String, String> env = pb.environment();

        if (config.getOracleHome() != null) {

File sqlPlusFile =
        new File(config.getSqlPlusPath());

String sqlPlusDirectory =
        sqlPlusFile.getParent();

env.put(
        "PATH",
        sqlPlusDirectory
);

if (config.getTnsAdmin() != null) {

    env.put(
        "TNS_ADMIN",
        config.getTnsAdmin()
    );
    
    LoggerUtil.log(
    "TNS_ADMIN FILE EXISTS = "
    + new File(
        config.getTnsAdmin()
        + File.separator
        + "tnsnames.ora"
    ).exists()
);
    
        LoggerUtil.log(
            "TNS_ADMIN="
            + env.get("TNS_ADMIN"));
        LoggerUtil.log(
        "ORACLE_HOME="
        + env.get("ORACLE_HOME"));

LoggerUtil.log(
        "PATH="
        + env.get("PATH"));
        
}
        }

        pb.redirectErrorStream(true);

        File sqlPlus =
        new File(config.getSqlPlusPath());

if (!sqlPlus.exists()) {

    throw new RuntimeException(
            "No existe sqlplus.exe: "
            + sqlPlus.getAbsolutePath());
}
        LoggerUtil.log("Inicio ejecución SQL");
        LoggerUtil.log("Oracle Home: " + config.getOracleHome());
        LoggerUtil.log("SQL Script: " + config.getSqlScript());
        LoggerUtil.log("Output File: " + config.getSqlOutputFile());
        
        
        Process process = pb.start();
        
        LoggerUtil.log("DESPUES DE START");
        LoggerUtil.log("SQLPlus iniciado");

        BufferedReader reader
                = new BufferedReader(
                        new InputStreamReader(
                                process.getInputStream()));
LoggerUtil.log("DESPUES DE preprar le buffer reader");
        String line;

        LoggerUtil.log("ANTES DEL WHILE");
        
        while ((line = reader.readLine()) != null) {
            LoggerUtil.log("[SQLPLUS] " + line);
        }
        
        LoggerUtil.log("despues DEL WHILE");
        LoggerUtil.log(
        "Process Alive: "
        + process.isAlive());
        int exitCode = process.waitFor();
        
        LoggerUtil.log(
        "Process Alive After Wait: "
        + process.isAlive());
        
        boolean sqlError = false;

       
        File output = new File(config.getSqlOutputFile());

        if (!output.exists()) {

            LoggerUtil.error(
                    "No se generó el spool: "
                    + output.getAbsolutePath(),
                    null
            );

            throw new RuntimeException(
                    "No se generó el archivo spool"
            );
        }

        if (exitCode != 0) {

            throw new RuntimeException(
                    "Error ejecutando SQLPLUS. ExitCode="
                    + exitCode
            );
        }

        LoggerUtil.log("SQL ejecutado correctamente");

        return config.getSqlOutputFile();
    }
}
