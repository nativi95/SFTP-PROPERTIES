/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.model;


public class FixedColumn {

    private String name;
    private int start;
    private int end;

    public FixedColumn(String name, int start, int end) {
        this.name = name;
        this.start = start;
        this.end = end;
    }

    public String getName() { return name; }
    public int getStart() { return start; }
    public int getEnd() { return end; }
}
