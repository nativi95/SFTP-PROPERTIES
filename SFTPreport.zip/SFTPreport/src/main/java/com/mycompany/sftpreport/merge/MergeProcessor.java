/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.merge;

import com.mycompany.sftpreport.config.ReportConfig;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author juan_nativi
 */
public class MergeProcessor {
 public static String merge(
        String file1,
        String file2,
        ReportConfig config)
        throws Exception {

    List<String> output =
            new ArrayList<>();

    System.out.println("SQL FILE : " + file1);
System.out.println("SFTP FILE: " + file2);
    List<String> file1Lines =
            Files.readAllLines(
                    Paths.get(file1));

    List<String> file2Lines =
            Files.readAllLines(
                    Paths.get(file2));

    // Agrega completo el primer archivo
    output.addAll(file1Lines);

    // Si se configuró omitir encabezados
    if (config.isSkipMergeHeaders()) {

        if (!file2Lines.isEmpty()) {

            output.addAll(
                    file2Lines.subList(
                            1,
                            file2Lines.size()));
        }

    } else {

        output.addAll(file2Lines);

    }

    Files.write(
            Paths.get(
                    config.getMergeOutputFile()),
            output);

    return config.getMergeOutputFile();
}
}
