/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.mailsender;


import com.mycompany.sftpreport.config.ReportConfig;
import com.mycompany.sftpreport.util.LoggerUtil;

import jakarta.mail.*;
import jakarta.mail.internet.*;

import java.io.File;
import java.time.LocalDate;
import java.util.Properties;

import com.mycompany.sftpreport.util.DateTemplateUtil;

public class MailSender {

    
    public static void send(ReportConfig config, String filePath, String reportName) {

        try {

            LoggerUtil.log("Inicio envío correo: " + reportName);

            Properties props = new Properties();

            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", config.getMailHost());
            props.put("mail.smtp.port", config.getMailPort());
            props.put("mail.smtp.ssl.trust", config.getMailHost());

            Session session = Session.getInstance(props,
                    new Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(
                                    config.getMailUser(),
                                    config.getMailPassword()
                            );
                        }
                    });

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(config.getMailUser()));

            // ✅ múltiples destinatarios
            for (String to : config.getMailTo().split(",")) {
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(to.trim()));
            }

            // ✅ subject dinámico      
             String subject = config.getMailSubjectTemplate().replace("{report}", reportName);
             subject = DateTemplateUtil.resolveDates(subject); 
             message.setSubject(subject);

            // ✅ adjunto
            MimeBodyPart attachment = new MimeBodyPart();
            attachment.attachFile(new File(filePath));

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(attachment);

            message.setContent(multipart);

            // ✅ enviar
            Transport.send(message);

            LoggerUtil.log("Correo enviado correctamente: " + reportName);

        } catch (Exception e) {

            LoggerUtil.error("Error enviando correo para: " + reportName, e);

            System.out.println("❌ ERROR MAIL: " + e.getMessage());

            // ✅ NO relanza excepción → no rompe ejecución general
        }
    }
}
