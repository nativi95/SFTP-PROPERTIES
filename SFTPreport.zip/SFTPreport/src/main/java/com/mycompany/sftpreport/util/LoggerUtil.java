/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.util;

/**
 *
 * @author juan_nativi
 */

import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class LoggerUtil {

    private static final String LOG_PATH = "C:\\SFTPreport\\config\\log.txt";

    public static void log(String message) {
        write("INFO", message);
    }

    public static void error(String message, Exception e) {
        write("ERROR", message + " - " + e.getMessage());
    }
    

    private static void write(String level, String message) {

        try (FileWriter fw = new FileWriter(LOG_PATH, true);
             PrintWriter pw = new PrintWriter(fw)) {

            pw.println(LocalDateTime.now() + " [" + level + "] " + message);

        } catch (Exception e) {
            System.out.println("Error escribiendo log: " + e.getMessage());
        }
    }
}
