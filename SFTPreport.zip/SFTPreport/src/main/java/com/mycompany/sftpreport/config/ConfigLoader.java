/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.config;



import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ConfigLoader {

    public static ReportConfig load(String reportName) throws Exception {

        String basePath = "C:\\SFTPreport\\config";

        File file = new File(basePath + "/" + reportName + ".properties");

        if (!file.exists()) {
            throw new RuntimeException("No existe config: " + file.getAbsolutePath());
        }

        Properties props = new Properties();
        FileInputStream fis = new FileInputStream(file);
        props.load(fis);

        return new ReportConfig(props);
    }
}


