package com.mycompany.sftpreport.textTransformer;

import com.mycompany.sftpreport.config.ReportConfig;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TextTransformer {

    public static String transform(String filePath,
            ReportConfig config)
            throws Exception {
        System.out.println("=== ENTRANDO A TEXT TRANSFORMER ===");
        List<String> lines
                = Files.readAllLines(
                        Paths.get(filePath));

        String delimiter = config.getDelimiter();

        String[] headers
                = config.getColumns()
                        .split(
                                Pattern.quote(delimiter));

        List<String> outputLines
                = new ArrayList<>();

        int startIndex = 0;

        if (config.hasHeader()) {
            System.out.println("hasHeader: " + config.hasHeader());
            System.out.println("includeHeader: " + config.isIncludeHeader());
            if (config.isIncludeHeader()) {
                outputLines.add(lines.get(0));
            }

            startIndex = 1;
        }

        for (int i = startIndex; i < lines.size(); i++) {

            String line = lines.get(i);

            if (line.trim().isEmpty()) {
                continue;
            }

            String[] values
                    = line.split(
                            Pattern.quote(delimiter),
                            -1);

            for (int j = 0;
                    j < values.length && j < headers.length;
                    j++) {

                String column = headers[j];

                String add
                        = config.getColumnTransform(
                                column,
                                "add");

                if (add != null) {

                    String currentValue = values[j].trim();

                    System.out.println(
                            "Columna: "
                            + column
                            + " Valor: ["
                            + currentValue
                            + "]"
                    );

                    if (!currentValue.isEmpty()) {

                        double value
                                = Double.parseDouble(currentValue);

                        value += Double.parseDouble(add);

                        values[j]
                                = String.format("%.2f", value);
                    }
                }
                String inputFormat
                        = config.getColumnTransform(
                                column,
                                "format");

                String outputFormat
                        = config.getColumnTransform(
                                column,
                                "outputFormat");

                if (inputFormat != null
                        && outputFormat != null) {

                    String currentValue
                            = values[j].trim();

                    if (!currentValue.isEmpty()) {

                        LocalDate date
                                = LocalDate.parse(
                                        currentValue,
                                        DateTimeFormatter.ofPattern(
                                                inputFormat));

                        values[j]
                                = date.format(
                                        DateTimeFormatter.ofPattern(
                                                outputFormat));
                    }
                }
            }

            outputLines.add(
                    String.join(
                            delimiter,
                            values));
        }

        String outputFile
                = filePath.replace(
                        ".txt",
                        "_transformado.txt");

        Files.write(
                Paths.get(outputFile),
                outputLines);
        System.out.println("Archivo transformado: " + outputFile);
        return outputFile;
    }

}
