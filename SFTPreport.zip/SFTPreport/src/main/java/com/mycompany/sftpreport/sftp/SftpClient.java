/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sftpreport.sftp;

import com.jcraft.jsch.*;
import com.mycompany.sftpreport.config.ReportConfig;
import com.mycompany.sftpreport.util.DateTemplateUtil;
import com.mycompany.sftpreport.util.LoggerUtil;

import java.io.File;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
//para mejorar formatos de fechas y tome valores como fecha-formato
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SftpClient {

    public static String download(ReportConfig config, String reportName) throws Exception {

        File dir = new File(config.getLocalPath());
        if (!dir.exists()) {
            dir.mkdirs();
        }

        JSch jsch = new JSch();

        Session session = jsch.getSession(
                config.getUser(),
                config.getHost(),
                config.getPort()
        );

        session.setPassword(config.getPassword());
        session.setConfig("StrictHostKeyChecking", "no");
        session.connect();

        Channel channel = session.openChannel("sftp");
        channel.connect();

        ChannelSftp sftp = (ChannelSftp) channel;

        String remotePath = resolveRemotePath(config, reportName);

        // ✅ DEBUG + LOG
        System.out.println("Ruta generada: " + remotePath);
        LoggerUtil.log("Intentando descargar: " + remotePath);

        String fileName = new File(remotePath).getName();
        String localFile = config.getLocalPath() + fileName;

        try {
            sftp.get(remotePath, localFile);
            LoggerUtil.log("Archivo descargado correctamente: " + remotePath);
        } catch (Exception e) {
            LoggerUtil.error("No se pudo descargar archivo: " + remotePath, e);

            System.out.println("❌ ERROR SFTP: Archivo no encontrado");
            throw e; // ✅ corta ejecución correctamente
        }

        sftp.exit();
        session.disconnect();

        return localFile;
    }
    
    
    /**
 * Procesa variables dinámicas de fecha dentro de una plantilla.
 *
 * Permite utilizar expresiones como:
 *
 * {today:ddMMyyyy}
 * {today:yyyyMMdd}
 * {yesterday:dd-MM-yyyy}
 * {lastdaymonth:ddMMyyyy}
 * {lastmonth:MMyyyy}
 *
 * Variables soportadas:
 *  - today         : fecha actual
 *  - yesterday     : fecha de ayer
 *  - lastdaymonth  : último día del mes anterior
 *  - lastmonth     : misma fecha del mes anterior
 *
 * El texto después de ":" corresponde al patrón DateTimeFormatter
 * que se utilizará para formatear la fecha.
 *
 * Ejemplos:
 *  {today:yyyyMMdd}           -> 20261006
 *  {yesterday:ddMMyyyy}       -> 05102026
 *  {lastdaymonth:ddMMyyyy}    -> 30092026
 *  {lastmonth:MMyyyy}         -> 092026
 *
 * Esto evita tener que crear una variable distinta para cada formato
 * de fecha requerido por los reportes.
 */
    private static String resolveDynamicDates(String template) {

    Pattern pattern = Pattern.compile("\\{(today|yesterday|lastdaymonth|lastmonth):([^}]+)\\}");

    Matcher matcher = pattern.matcher(template);

    StringBuffer result = new StringBuffer();

    LocalDate today = LocalDate.now();

    while (matcher.find()) {

        String variable = matcher.group(1);
        String format = matcher.group(2);

        LocalDate date;

        switch (variable.toLowerCase()) {

            case "today":
                date = today;
                break;

            case "yesterday":
                date = today.minusDays(1);
                break;

            case "lastdaymonth":
                date = today.withDayOfMonth(1).minusDays(1);
                break;

            case "lastmonth":
                date = today.minusMonths(1);
                break;

            default:
                date = today;
        }

        String replacement =
                date.format(DateTimeFormatter.ofPattern(format));

        matcher.appendReplacement(
                result,
                Matcher.quoteReplacement(replacement)
        );
    }

    matcher.appendTail(result);

    return result.toString();
}

    /**
     * 
     * Se actualzia el metodo para recibir los nuevos formatos de fecha
     * private static String resolveRemotePath(ReportConfig config, String reportName) {
     

    String template = config.getRemoteTemplate();

    if (template == null || template.isEmpty()) {
        return config.getRemotePath();
    }

    LocalDate today = LocalDate.now();
    LocalDate yesterday = today.minusDays(1);

    // Último día del mes anterior
    LocalDate lastDayPreviousMonth = today.withDayOfMonth(1).minusDays(1);

    Month month = today.getMonth();

    String monthLower = month.getDisplayName(
            java.time.format.TextStyle.FULL,
            new Locale("es", "ES")
    ).toLowerCase();

    String monthCapitalized =
            monthLower.substring(0, 1).toUpperCase() + monthLower.substring(1);

    String monthUpper = monthLower.toUpperCase();

    return template
            .replace("{report}", reportName)

            // Año / Mes
            .replace("{year}", today.format(DateTimeFormatter.ofPattern("yyyy")))
            .replace("{month}", today.format(DateTimeFormatter.ofPattern("MM")))
            .replace("{lastMonth}", today.minusMonths(1)
                    .format(DateTimeFormatter.ofPattern("yyyyMM")))
            .replace("{lastMonthMMyyyy}", today.minusMonths(1)
                    .format(DateTimeFormatter.ofPattern("MMyyyy")))

            // Hoy
            .replace("{date}", today.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
            .replace("{dateDDMMYYYY}", today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")))
            .replace("{dateDDMMYY}", today.format(DateTimeFormatter.ofPattern("dd-MM-yy")))

            // Ayer
            .replace("{yesterday}", yesterday.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
            .replace("{yesterdayDDMMYYYY}", yesterday.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")))
            .replace("{yesterdayDDMMYY}", yesterday.format(DateTimeFormatter.ofPattern("dd-MM-yy")))

            // Último día del mes anterior
            .replace("{lastMonthddMMyyyy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("ddMMyyyy")))
            .replace("{lastMonthddMMyy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("ddMMyy")))
            .replace("{lastMonthyyyyMMdd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yyyyMMdd")))
            .replace("{lastMonthyyMMdd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yyMMdd")))

            .replace("{lastMonthdd-MM-yyyy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")))
            .replace("{lastMonthdd-MM-yy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("dd-MM-yy")))
            .replace("{lastMonthyyyy-MM-dd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
            .replace("{lastMonthyy-MM-dd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yy-MM-dd")))

            .replace("{lastMonthdd/MM/yyyy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
            .replace("{lastMonthdd/MM/yy}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("dd/MM/yy")))
            .replace("{lastMonthyyyy/MM/dd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yyyy/MM/dd")))
            .replace("{lastMonthyy/MM/dd}",
                    lastDayPreviousMonth.format(DateTimeFormatter.ofPattern("yy/MM/dd")))

            // Meses en texto
            .replace("{monthName}", monthCapitalized)
            .replace("{monthNameLower}", monthLower)
            .replace("{monthNameUpper}", monthUpper);
}*/
    
    
    /**
 * Construye la ruta remota final del archivo a descargar desde el SFTP.
 *
 * Toma la plantilla configurada en el archivo properties y reemplaza
 * las variables dinámicas por sus valores correspondientes según la fecha
 * de ejecución y el nombre del reporte.
 *
 * Soporta variables de año, mes, fecha y nombres de mes, así como
 * expresiones dinámicas de fecha con formato configurable.
 *
 * Ejemplos:
 *   {report}                     -> REPORTE_DIARIO
 *   {year}                       -> 2026
 *   {month}                      -> 10
 *   {monthName}                  -> Octubre
 *   {today:yyyyMMdd}             -> 20261006
 *   {yesterday:ddMMyyyy}         -> 05102026
 *   {lastdaymonth:ddMMyyyy}      -> 30092026
 *   {lastmonth:MMyyyy}           -> 092026
 *
 * Si no se encuentra una plantilla (sftp.remote.template),
 * se utiliza la ruta estática configurada en sftp.remote.path.
 *
 * @param config Configuración del reporte obtenida desde el archivo properties.
 * @param reportName Nombre lógico del reporte que se está procesando.
 * @return Ruta completa del archivo a buscar en el servidor SFTP.
 
    
    private static String resolveRemotePath(ReportConfig config, String reportName) {
     

    String template = config.getRemoteTemplate();

    if (template == null || template.isEmpty()) {
        return config.getRemotePath();
    }

    LocalDate today = LocalDate.now();
    LocalDate yesterday = today.minusDays(1);

    // Último día del mes anterior
    LocalDate lastDayPreviousMonth = today.withDayOfMonth(1).minusDays(1);

    Month month = today.getMonth();

    String monthLower = month.getDisplayName(
            java.time.format.TextStyle.FULL,
            new Locale("es", "ES")
    ).toLowerCase();

    String monthCapitalized =
            monthLower.substring(0, 1).toUpperCase() + monthLower.substring(1);

    String monthUpper = monthLower.toUpperCase();
    String resolved = template
    .replace("{report}", reportName)
    .replace("{year}", today.format(DateTimeFormatter.ofPattern("yyyy")))
    .replace("{month}", today.format(DateTimeFormatter.ofPattern("MM")))
    .replace("{monthName}", monthCapitalized)
    .replace("{monthNameLower}", monthLower)
    .replace("{monthNameUpper}", monthUpper);
    return resolveDynamicDates(resolved); 
    }*/
    
    
    private static String resolveRemotePath(ReportConfig config, String reportName) {

    String template = config.getRemoteTemplate();

    if (template == null || template.isEmpty()) {
        return config.getRemotePath();
    }

    LocalDate today = LocalDate.now();

    Month month = today.getMonth();

    String monthLower = month.getDisplayName(
            java.time.format.TextStyle.FULL,
            new Locale("es", "ES")
    ).toLowerCase();

    String monthCapitalized =
            monthLower.substring(0, 1).toUpperCase() + monthLower.substring(1);

    String monthUpper = monthLower.toUpperCase();

    String resolved = template
            .replace("{report}", reportName)
            .replace("{year}", today.format(DateTimeFormatter.ofPattern("yyyy")))
            .replace("{month}", today.format(DateTimeFormatter.ofPattern("MM")))
            .replace("{monthName}", monthCapitalized)
            .replace("{monthNameLower}", monthLower)
            .replace("{monthNameUpper}", monthUpper);

    return DateTemplateUtil.resolveDates(resolved);
}
}
